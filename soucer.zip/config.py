# Bot token.
BOT_TOKEN = "8196164356:AAFbMdFxGmaU2zJOyC8QkmDy_7hc742nG0E"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed.
API_ID = 17726932
API_HASH = "ced945acfcd9d2d2cf6a448841a9d54e"

# CHAT DE ERROS
LOG_CHAT = -1001768400412

# LOGS DE COMPRAS E ADD SALDO
ADMIN_CHAT = -1001768400412

# CHAT DE COMPRAS PARA CLIENTE
CLIENT_CHAT = -1001681258433
# Quantas atualiza��es podem ser tratadas em paralelo.
# N�o use valores altos para servidores low-end.
WORKERS = 20

# Os administradores podem acessar o painel e adicionar novos materiais ao bot.
ADMINS = [6744390073]

# Sudoers t�m acesso total ao servidor e podem executar comandos.
SUDOERS = [6744390073]

# All sudoers should be admins too
ADMINS.extend(SUDOERS)

GIFTERS = []